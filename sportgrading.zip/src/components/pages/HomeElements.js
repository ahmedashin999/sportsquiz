import styled from 'styled-components';

 export const HeroInfo=styled.div`
 height:400px;
 
background:#fff;


 margin-top:0px;
 
 `;
 export const HeroIntro=styled.div`
 margin-top:30px;
  font-size:20px;
  color:#333;
  margin-left:30px;
 `
 export const InfoH2=styled.h2`
   color:#333;
 
 `
 export const Infop1=styled.p`
 
 `
 export const Infop2=styled.p`
 
 `
 export const Infop3=styled.p`
 
 `
 export const Infop4=styled.p`
 
 `
  export const HeroPic=styled.div`
  
  
  `